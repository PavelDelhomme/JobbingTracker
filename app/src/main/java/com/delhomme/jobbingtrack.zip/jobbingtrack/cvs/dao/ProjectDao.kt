package com.delhomme.jobbingtrack.cvs.dao


import androidx.room.*
import com.delhomme.jobbingtrack.cvs.entities.ProjectEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects WHERE isDeleted = 0")
    fun getAll(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :id LIMIT 1")
    fun getById(id: String): Flow<ProjectEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(entity: ProjectEntity)

    @Delete
    suspend fun delete(entity: ProjectEntity)
}
