package com.delhomme.jobbingtrack.applications.entities


import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.delhomme.jobbingtrack.commons.fields.CommonEntityFields
import com.delhomme.jobbingtrack.commons.interfaces.HasIdProvider
import java.util.UUID

@Entity(tableName = "applications")
data class ApplicationEntity(
    @PrimaryKey override val id: String = UUID.randomUUID().toString(),
    val title: String,
    val companyId: String,
    val applicationDate: Long,
    val platform: String?,
    val contractType: String?,
    val location: String?,
    val applicationType: String,
    val applicationStatus: String,
    val notes: String?,
    val followUpsIds: List<String> = emptyList(),
    val contactsIds: List<String> = emptyList(),
    val callsIds: List<String> = emptyList(),
    val interviewsIds: List<String> = emptyList(),
    @Embedded val base: CommonEntityFields
) : HasIdProvider