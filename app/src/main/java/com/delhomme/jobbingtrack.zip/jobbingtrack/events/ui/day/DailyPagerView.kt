package com.delhomme.jobbingtrack.events.ui.day


import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.delhomme.jobbingtrack.applications.entities.ApplicationEntity
import com.delhomme.jobbingtrack.commons.entities.InterviewWithContacts
import com.delhomme.jobbingtrack.contacts.entities.ContactEntity
import com.delhomme.jobbingtrack.events.entities.EventEntity
import com.google.accompanist.pager.*
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

@OptIn(ExperimentalPagerApi::class)
@Composable
fun DailyPagerView(
    initialDate: LocalDate,
    events: List<EventEntity>,
    onDateChange: (LocalDate) -> Unit,
    userId: String,
    interviews: List<InterviewWithContacts> = emptyList(),
    contacts: List<ContactEntity> = emptyList(),
    applications: List<ApplicationEntity> = emptyList(),
    calls: List<CallEntity> = emptyList(),
    followsUp: List<FollowUpEntity> = emptyList(),
) {
    val pagerState = rememberPagerState(initialPage = 1000) // Centre fictif
    val currentDate by remember {
        derivedStateOf { initialDate.plusDays((pagerState.currentPage - 1000).toLong()) }
    }

    LaunchedEffect(currentDate) {
        onDateChange(currentDate)
    }

    HorizontalPager(
        count = Int.MAX_VALUE,
        state = pagerState,
        modifier = Modifier.fillMaxSize()
    ) { page ->
        val pageDate = initialDate.plusDays((page - 1000).toLong())

        InteractiveDayView(
            date = pageDate,
            eventEntities = events.filter {
                Instant.ofEpochMilli(it.startDate?.toLong() ?: 0)
                    .atZone(ZoneId.systemDefault()).toLocalDate() == pageDate
            },
            userId = userId,
            interviews = interviews,
            contacts = contacts,
            applications = applications,
            calls = calls,
            followsUp = followsUp,
        )
    }
}