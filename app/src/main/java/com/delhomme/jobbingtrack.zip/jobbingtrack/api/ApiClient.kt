package com.delhomme.jobbingtrack.api


import android.content.Context
import com.delhomme.jobbingtrack.api.tokens.TokenAuthenticator
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import kotlin.getValue
import kotlin.jvm.java

object ApiClient {
    internal const val BASE_URL = "http://192.168.1.134:8000/api/"
    private lateinit var appContext: Context

    /** Appel unique, le plus tôt possible (Application#onCreate) */
    fun init(context: Context) {
        appContext = context.applicationContext
    }

    private val okHttp: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .authenticator(TokenAuthenticator(appContext))
            .addInterceptor(AuthInterceptor(appContext))
            .build()
    }

    val api: ApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttp)
            .addConverterFactory(MoshiConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }
}