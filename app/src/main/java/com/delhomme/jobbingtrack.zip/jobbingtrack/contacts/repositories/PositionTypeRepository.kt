package com.delhomme.jobbingtrack.contacts.repositories

import com.delhomme.jobbingtrack.contacts.dao.PositionTypeDao
import com.delhomme.jobbingtrack.contacts.entities.PositionTypeEntity
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class PositionTypeRepository @Inject constructor(
    private val dao: PositionTypeDao
) {
    val all: Flow<List<PositionTypeEntity>> = dao.getAll()
    fun byId(id: String): Flow<PositionTypeEntity?> = dao.getById(id)
    suspend fun save(entity: PositionTypeEntity) = dao.save(entity)
    suspend fun delete(entity: PositionTypeEntity) = dao.delete(entity)
}
